import hashlib, json, re, sys
from pathlib import Path
from zipfile import ZipFile
root=Path(sys.argv[1] if len(sys.argv)>1 else 'harness_reference/AI-RV-Harness-ai-rv-2')
zp=Path(sys.argv[2] if len(sys.argv)>2 else 'p1_sources/AI RV Harness/AI-RV-Harness-ai-rv-2.zip')
out=Path(sys.argv[3] if len(sys.argv)>3 else 'ai_home_p1/evidence')
checked=0
with ZipFile(zp) as z:
 assert z.testzip() is None
 for i in z.infolist():
  if i.is_dir():continue
  rel='/'.join(i.filename.split('/')[1:]);assert (root/rel).read_bytes()==z.read(i.filename),rel;checked+=1
 comment=z.comment.decode('utf8','replace')
paths=set(['LICENSE','CONTENT_LICENSE_CC_BY_4.0.md','CREDITS.md','README.md','package.json','package-lock.json','src-tauri/Cargo.toml','src-tauri/Cargo.lock','src-tauri/tauri.conf.json','src-tauri/capabilities/default.json','src-tauri/src/providers.rs','src-tauri/src/secrets.rs','src-tauri/src/documents.rs','src-tauri/src/dialogs.rs','src/attachments/native.ts','src/sources/service.ts','src/features/profiles/useProfileSetupController.ts','src/features/profiles/ProfileSetupUnifiedController.test.ts','src/i18n.ts','src/aiCenter/fieldGuideUpdate.ts','src/aiCenter/fieldGuide.ts','src/aiCenter/fieldGuideUpdate.test.ts','src/aiCenter/viewerNotes.ts','src/aiCenter/viewerNotes.test.ts','src/aiCenter/types.ts','src/aiCenter/fieldGuideTypes.ts'])
for folder in ['src/providers','src-tauri/src/providers','src/i18n']:
 paths.update(str(p.relative_to(root)) for p in (root/folder).rglob('*') if p.is_file())
records=[]
for rel in sorted(paths):
 p=root/rel
 if not p.exists():continue
 raw=p.read_bytes();r={'path':rel,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'imports':[]}
 if p.suffix in ['.ts','.tsx']:r['imports']=sorted(set(re.findall(r'from\s+[\'"]([^\'"]+)[\'"]',raw.decode())))
 records.append(r)
allfiles=[(str(p.relative_to(root)),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()]
digest=hashlib.sha256(''.join(h+'  '+r+'\n' for r,h in allfiles).encode()).hexdigest()
out.mkdir(exist_ok=True,parents=True)
(out/'HARNESS_SOURCE_INVENTORY.json').write_text(json.dumps({'zip_sha256':hashlib.sha256(zp.read_bytes()).hexdigest(),'library_file_id':'libfile_a0b47fe1ecc08191b91a3531fbd73509','zip_comment':comment,'archive_files_verified_byte_identical':checked,'tree_digest_algorithm':'SHA256(sorted lines: file-sha256 + two spaces + relative-path + LF)','tree_sha256':digest,'records_scope':'selected reuse candidates, their tests and metadata; not an exhaustive security review','records':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive_files':checked,'zip_comment':comment,'tree_sha256':digest,'candidate_inventory_files':len(records)}))
