// Run original pure functions from the audited TS snapshot under Node 24.
// This does not run Vitest, Rust, Tauri or live providers.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';import {stripTypeScriptTypes} from 'node:module';import {pathToFileURL} from 'node:url';
const base=path.resolve(process.argv[2]||'harness_reference/AI-RV-Harness-ai-rv-2');const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'aihome-p1-pure-'));let count=0;
const ok=v=>{assert(v);count++};
try{
 for(const name of ['providerError','retry','continuationContract','googleContinuation','anthropicContinuation']){
  let js=stripTypeScriptTypes(fs.readFileSync(path.join(base,'src/providers',name+'.ts'),'utf8'),{mode:'transform'});
  js=js.replace(/from "\.\/([^"]+)"/g,'from "./$1.mjs"');fs.writeFileSync(path.join(tmp,name+'.mjs'),js);
 }
 const retry=await import(pathToFileURL(path.join(tmp,'retry.mjs'))),contract=await import(pathToFileURL(path.join(tmp,'continuationContract.mjs')));
 const cause=(httpStatus,extra={})=>({code:'http_status',message:'test',phase:'awaiting_headers',httpStatus,...extra});
 for(const status of [408,425,429,500,502,503,504,524,529]){ok(retry.isStandardRetryHttpStatus(status));ok(retry.providerRetryAllowance(cause(status),2)===2);}
 for(const status of [400,401,403,404])ok(retry.providerRetryAllowance(cause(status),2)===0);
 ok(retry.providerRetryAllowance(cause(429,{semanticOutputStarted:true}),2)===0);ok(retry.providerRetryAllowance(cause(429),0)===0);ok(retry.providerRetryDelayMs(0,cause(429,{retryAfterMs:120000}),()=>0.5)===30000);
 for(const filename of ['google-thought-signature','anthropic-thinking-blocks','openrouter-reasoning-details']){
  const fixture=JSON.parse(fs.readFileSync(path.join(base,'src/providers/continuation-fixtures',filename+'.json'),'utf8'));const state=fixture.continuationState;
  ok(contract.validateProviderContinuationState(state).ok);ok(contract.validateContinuationRequestBudget([state]).ok);
  ok(contract.replayFingerprintsCompatible(state.replayFingerprint,{...state.replayFingerprint}));
  ok(!contract.replayFingerprintsCompatible(state.replayFingerprint,{...state.replayFingerprint,credentialId:'different'}));
  ok(!contract.replayFingerprintsCompatible(state.replayFingerprint,{...state.replayFingerprint,requestedModelId:'different'}));
 }
 ok(!contract.validateProviderContinuationState({schemaVersion:999}).ok);
 const google=await import(pathToFileURL(path.join(tmp,'googleContinuation.mjs')));const f=JSON.parse(fs.readFileSync(path.join(base,'src/providers/continuation-fixtures/google-thought-signature.json'),'utf8'));const fp=f.continuationState.replayFingerprint;
 const captured=google.captureGoogleContinuationState({config:{provider:'google',id:fp.providerConfigId,credentialId:fp.credentialId},requestedModelId:fp.requestedModelId,normalizedEndpoint:fp.normalizedEndpoint,parts:f.continuationState.parts,visibleContent:'Visible fixture answer.'});ok(!!captured.state);
 ok(!!google.captureGoogleContinuationState({config:{provider:'google',id:fp.providerConfigId,credentialId:fp.credentialId},requestedModelId:fp.requestedModelId,normalizedEndpoint:fp.normalizedEndpoint,parts:f.continuationState.parts,visibleContent:'wrong'}).issue);
 console.log('PASS:',count,'assertions against original pure Harness functions; no live API/native build');
}finally{fs.rmSync(tmp,{recursive:true,force:true})}
