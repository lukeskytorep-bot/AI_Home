# P1 — dowody audytu

Pakiet zawiera inwentarz źródeł, skrypty kontroli i zapis wyników. Nie zawiera runtime AI Home ani kopii źródeł Harness.

Uruchomienie ze źródłami opisanymi w raporcie:

```bash
python3 source_inventory.py /path/to/extracted/root /path/to/source.zip /path/to/output
node p0_regression.cjs /path/to/AI_HOME_P0_MAKIETA.html
node harness_pure_smoke.mjs /path/to/extracted/root
```

Python 3, Node 24. Test makiety używa zastępczego DOM i nie potwierdza renderowania. Smoke Harness testuje oryginalne pure functions po tymczasowym usunięciu typów przez Node, nie uruchamia pełnego Vitest/native. Hash drzewa opisano w HARNESS_SOURCE_INVENTORY.json; komentarz ZIP nie został zweryfikowany zdalnie.
